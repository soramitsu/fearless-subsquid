export const RewardPaymentDelay = 2
export const DefaultCollatorCommission = 20
