

export interface ActionData {
    id: string,
    timestamp: Date
    blockNumber: number,
    extrinsicHash?: string,
}