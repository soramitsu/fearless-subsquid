import staking from './staking'

export { staking }
